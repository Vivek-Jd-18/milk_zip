import React from 'react'
import { useWeb3React } from '@web3-react/core'
import masterChefAbi from "../../abi/masterchef.json";
import {lotteryContracts,masterChefContracts,milkContracts,lpContract} from "../../common/abicalls"

const Harvest = async (pid) => {
    const { account, activate, deactivate } = useWeb3React()
    // const harvestHAndler = async (masterChefContract, pid, account) => {
    const masterChefAddress = "0x9c19eB54c759c9369C788D6554f08Bb6cAdab10d";


    const harvestResponse = masterChefContracts().methods
        .deposit(pid, '0')
        .send({ from: account })
        .on('transactionHash', (tx) => {
            return tx.transactionHash
        })
    // console.log("=-=-harvestResponse-=-=", await harvestResponse);
    return  harvestResponse
}
// }

export default Harvest
