const priceContracts: { cakeAddress: string; busdAddress: string; lpAddress: string } = {
  cakeAddress: '0xc9bCF3f71E37579A4A42591B09c9dd93Dfe27965',
  busdAddress: '0xe9e7cea3dedca5984780bafc599bd69add087d56',
  lpAddress: '0xAb6DEeC8C64aE4964Ba5e153d12b8acD1632a29F',
}

export default priceContracts
