experiments: {
    topLevelAwait: true
  }