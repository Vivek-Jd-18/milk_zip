import React from 'react'

const HedaerBoot = () => {
  return (
    <div>HedaerBoot</div>
  )
}

export default HedaerBoot